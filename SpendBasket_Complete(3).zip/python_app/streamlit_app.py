"""Streamlit Web Interface for SpendBasket — Grocery Budget Assistant."""
from __future__ import annotations

import csv
import io
from collections import defaultdict
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Dict, List

import streamlit as st

from analytics import classify_status, compute_executive_summary, export_markdown_report
from charts import generate_budget_charts
from models import BudgetConfig, GroceryRecord, VALID_CATEGORIES
from storage import (
    DATA_DIR,
    load_budget_config,
    load_raw_budget_config,
    load_records,
    save_budget_config,
    save_raw_budget_config,
    save_records,
)
from validator import validate_record_payload

CATEGORY_COLORS: Dict[str, str] = {
    "Fresh Fruits & Veggies": "#10b981",
    "Milk, Cheese & Eggs": "#0ea5e9",
    "Meat, Poultry & Fish": "#f43f5e",
    "Bread & Bakery": "#f59e0b",
    "Snacks & Sweets": "#ec4899",
    "Drinks & Coffee": "#14b8a6",
    "Rice, Pasta & Grains": "#6366f1",
    "Spices, Sauces & Oils": "#f97316",
    "Frozen Meals & Ice Cream": "#06b6d4",
    "Breakfast & Cereal": "#eab308",
    "Baby & Pet Care": "#84cc16",
    "Cleaning & Home Supplies": "#8b5cf6",
}


def get_all_categories(raw_cfg: Dict[str, object], records: List[GroceryRecord]) -> List[str]:
    cats = list(VALID_CATEGORIES)
    for custom in raw_cfg.get("customCategories", []):  # type: ignore[union-attr]
        if isinstance(custom, dict) and custom.get("name"):
            name = str(custom["name"])
            if name not in cats:
                cats.append(name)
    for r in records:
        if r.category and r.category not in cats:
            cats.append(r.category)
    return cats


def records_to_csv_bytes(records: List[GroceryRecord]) -> bytes:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        [
            "ID",
            "Item",
            "Category",
            "Quantity",
            "Unit Price",
            "Total Cost",
            "Target Budget",
            "Savings/Over",
            "Date",
            "Store",
            "Notes",
        ]
    )
    for r in records:
        writer.writerow(
            [
                r.id,
                r.item_name,
                r.category,
                f"{r.quantity:.2f}",
                f"{r.unit_price:.2f}",
                f"{r.total_cost:.2f}",
                f"{r.item_budget:.2f}",
                f"{r.variance:+.2f}",
                r.purchase_date,
                r.store,
                r.notes,
            ]
        )
    return buf.getvalue().encode("utf-8")


def main() -> None:
    st.set_page_config(
        page_title="SpendBasket — Grocery Budget Assistant",
        page_icon="🛒",
        layout="wide",
    )

    st.markdown(
        """
        <style>
        .sb-hero {
            padding: 1.5rem 1.75rem;
            border-radius: 16px;
            color: #ffffff;
            margin-bottom: 1.25rem;
        }
        .sb-hero-ok {
            background: linear-gradient(135deg, #059669 0%, #0d9488 55%, #0284c7 100%);
        }
        .sb-hero-warn {
            background: linear-gradient(135deg, #d97706 0%, #ea580c 60%, #e11d48 100%);
        }
        .sb-hero-over {
            background: linear-gradient(135deg, #e11d48 0%, #dc2626 60%, #ea580c 100%);
        }
        .sb-cat-card {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 0.85rem 1rem;
            background: #ffffff;
            margin-bottom: 0.75rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    records, storage_notice = load_records()
    config = load_budget_config()
    raw_cfg = load_raw_budget_config()
    all_categories = get_all_categories(raw_cfg, records)
    summary = compute_executive_summary(records, config)

    # Sidebar: Quick Add Purchase Form
    with st.sidebar:
        st.title("SpendBasket")
        st.caption("Smart Grocery Budget Assistant (Python Streamlit UI)")
        st.divider()
        st.subheader("Log a Grocery Purchase")
        with st.form("add_grocery_form", clear_on_submit=True):
            item_name = st.text_input(
                "What did you buy?", placeholder="e.g. Honeycrisp Apples"
            )
            category = st.selectbox("Category", all_categories)
            col_q, col_p = st.columns(2)
            with col_q:
                quantity = st.number_input("Quantity", min_value=0.01, value=1.0, step=1.0)
            with col_p:
                unit_price = st.number_input(
                    "Price each ($)", min_value=0.01, value=4.50, step=0.25
                )
            item_budget = st.number_input(
                "Target Limit ($)", min_value=0.01, value=10.00, step=0.50
            )
            purchase_date = st.date_input("Shopping Date", value=date.today())
            store = st.text_input("Store", value="FreshMarket")
            notes = st.text_input("Notes (optional)", placeholder="Weekly groceries")
            submitted = st.form_submit_button("Add to My Groceries", type="primary", use_container_width=True)

            if submitted:
                payload = {
                    "item_name": item_name,
                    "category": category,
                    "quantity": quantity,
                    "unit_price": unit_price,
                    "item_budget": item_budget,
                    "purchase_date": purchase_date.strftime("%Y-%m-%d"),
                    "store": store,
                    "notes": notes,
                }
                errs, cleaned = validate_record_payload(payload, all_categories)
                if errs or not cleaned:
                    for err in errs:
                        st.error(err)
                else:
                    existing_ids = {r.id for r in records}
                    next_num = 1001 + len(records)
                    while f"GRB-{next_num}" in existing_ids:
                        next_num += 1
                    new_rec = GroceryRecord(
                        id=f"GRB-{next_num}",
                        created_at=datetime.now(timezone.utc).isoformat(),
                        **cleaned,
                    )
                    updated = [new_rec, *records]
                    save_records(updated)
                    if new_rec.total_cost > new_rec.item_budget:
                        st.warning(
                            f"Saved {new_rec.item_name} (${new_rec.total_cost:.2f}) — Over target by ${new_rec.total_cost - new_rec.item_budget:.2f}!"
                        )
                    else:
                        st.success(
                            f"Saved {new_rec.item_name} (${new_rec.total_cost:.2f}) — On Track!"
                        )
                    st.rerun()

    if storage_notice:
        st.info(storage_notice)

    tab_overview, tab_groceries, tab_categories, tab_reports = st.tabs(
        ["Overview", "My Groceries", "Categories & Limits", "Reports & Export"]
    )

    with tab_overview:
        status = summary["overall_status"]
        hero_cls = (
            "sb-hero-over"
            if status == "Over Budget"
            else "sb-hero-warn"
            if status == "Near Limit"
            else "sb-hero-ok"
        )
        rem = float(summary["remaining"])
        rem_text = (
            f"You're ${abs(rem):.2f} over your monthly limit"
            if rem < 0
            else f"You have ${rem:.2f} left to spend this month"
        )

        st.markdown(
            f"""
            <div class="sb-hero {hero_cls}">
              <div style="font-size:0.9rem;opacity:0.9;font-weight:500;">Monthly Grocery Budget</div>
              <div style="font-size:2.35rem;font-weight:700;margin:0.25rem 0;">
                ${summary['total_spend']:.2f} <span style="font-size:1.1rem;font-weight:400;opacity:0.85;">spent of ${summary['overall_budget']:.0f}</span>
              </div>
              <div style="font-size:0.95rem;opacity:0.95;">{rem_text} ({summary['utilization_pct']:.1f}% used)</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.progress(min(1.0, float(summary["utilization_pct"]) / 100.0))

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Spent", f"${summary['total_spend']:.2f}")
        m2.metric(
            "Remaining / Over",
            f"{'+' if rem >= 0 else '-'}${abs(rem):.2f}",
        )
        m3.metric("Items Logged", str(summary["total_entries"]))
        m4.metric("Overspent Flags", str(summary["overspent_count"]))

        # Overspending & Category Alerts
        over_cats = [
            c for c in summary["categories"] if c["status"] in ("Over Budget", "Near Limit")
        ]
        if over_cats:
            st.subheader("Heads Up on Your Spending")
            alert_cols = st.columns(min(3, len(over_cats)))
            for idx, c in enumerate(over_cats[:3]):
                with alert_cols[idx]:
                    if c["status"] == "Over Budget":
                        st.error(
                            f"**{c['category']}** is over limit: ${c['spent']:.2f} / ${c['budget']:.2f}"
                        )
                    else:
                        st.warning(
                            f"**{c['category']}** is near limit: ${c['spent']:.2f} / ${c['budget']:.2f}"
                        )

        col_chart1, col_chart2 = st.columns(2)
        with col_chart1:
            st.subheader("Spending by Category ($)")
            cat_chart_data = {
                c["category"]: c["spent"]
                for c in summary["categories"]
                if c["spent"] > 0
            }
            if cat_chart_data:
                st.bar_chart(cat_chart_data)
            else:
                st.info("No spending logged yet.")

        with col_chart2:
            st.subheader("Cumulative Spending Trend ($)")
            daily = defaultdict(float)
            for r in records:
                daily[r.purchase_date] += r.total_cost
            running = 0.0
            trend_data: Dict[str, float] = {}
            for d in sorted(daily.keys()):
                running = round(running + daily[d], 2)
                trend_data[d] = running
            if trend_data:
                st.line_chart(trend_data)
            else:
                st.info("Add purchases to see your spending curve.")

        st.subheader("Categories at a Glance")
        grid_cols = st.columns(3)
        for idx, c in enumerate(summary["categories"]):
            color = CATEGORY_COLORS.get(c["category"], "#059669")
            with grid_cols[idx % 3]:
                st.markdown(
                    f"""
                    <div class="sb-cat-card" style="border-top: 4px solid {color};">
                      <div style="font-weight:600;color:#0f172a;">{c['category']}</div>
                      <div style="font-size:1.15rem;font-weight:700;margin:0.2rem 0;">
                        ${c['spent']:.2f} <span style="font-size:0.8rem;font-weight:400;color:#64748b;">/ ${c['budget']:.0f} limit</span>
                      </div>
                      <div style="font-size:0.8rem;color:#475569;">{c['items']} items · {c['status']}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    with tab_groceries:
        st.subheader("My Groceries")
        f1, f2, f3 = st.columns([2, 1.5, 1.2])
        with f1:
            kw = st.text_input("Search item, store, or notes", key="search_kw")
        with f2:
            cat_filter = st.selectbox("Category", ["All"] + all_categories, key="cat_filter")
        with f3:
            status_filter = st.selectbox(
                "Status",
                ["All", "On Track", "Near Limit", "Over Target"],
                key="status_filter",
            )

        filtered = []
        for r in records:
            if cat_filter != "All" and r.category != cat_filter:
                continue
            item_status = classify_status(
                r.total_cost, r.item_budget, config.warning_threshold_pct
            )
            friendly_status = (
                "Over Target"
                if item_status == "Over Budget"
                else "Near Limit"
                if item_status == "Near Limit"
                else "On Track"
            )
            if status_filter != "All" and friendly_status != status_filter:
                continue
            if kw.strip():
                q = kw.strip().lower()
                if (
                    q not in r.item_name.lower()
                    and q not in r.store.lower()
                    and q not in r.category.lower()
                    and q not in r.notes.lower()
                ):
                    continue
            filtered.append((r, friendly_status))

        st.caption(f"Showing {len(filtered)} of {len(records)} items")

        for r, friendly_status in filtered:
            c1, c2, c3, c4 = st.columns([3.5, 1.8, 1.5, 0.8])
            c1.markdown(
                f"**{r.item_name}**  \n`{r.category}` · {r.store} · {r.purchase_date}"
            )
            c2.markdown(
                f"**${r.total_cost:.2f}** ({r.quantity:g} × ${r.unit_price:.2f})  \nTarget: ${r.item_budget:.2f}"
            )
            if friendly_status == "Over Target":
                c3.error(f"Over by ${abs(r.variance):.2f}")
            elif friendly_status == "Near Limit":
                c3.warning(f"Near Limit (+${r.variance:.2f})")
            else:
                c3.success(f"Saved ${r.variance:.2f}")

            if c4.button("Delete", key=f"del_{r.id}"):
                remaining = [item for item in records if item.id != r.id]
                save_records(remaining)
                st.rerun()

    with tab_categories:
        st.subheader("Monthly Budget & Category Limits")
        with st.form("budget_limits_form"):
            b1, b2 = st.columns(2)
            with b1:
                new_overall = st.number_input(
                    "Monthly Grocery Budget ($)",
                    min_value=1.0,
                    value=float(config.overall_monthly_budget),
                    step=10.0,
                )
            with b2:
                new_warn = st.slider(
                    "Early Warning Threshold (%)",
                    min_value=50,
                    max_value=99,
                    value=int(config.warning_threshold_pct),
                )

            st.markdown("#### Per-Category Monthly Limits ($)")
            cat_inputs: Dict[str, float] = {}
            cols = st.columns(3)
            for idx, cat in enumerate(all_categories):
                with cols[idx % 3]:
                    cat_inputs[cat] = st.number_input(
                        cat,
                        min_value=1.0,
                        value=float(config.category_budgets.get(cat, 40.0)),
                        step=5.0,
                        key=f"cfg_{cat}",
                    )

            if st.form_submit_button("Save All Limits", type="primary"):
                next_cfg = BudgetConfig(
                    overall_monthly_budget=round(new_overall, 2),
                    warning_threshold_pct=float(new_warn),
                    category_budgets={k: round(v, 2) for k, v in cat_inputs.items()},
                )
                save_budget_config(next_cfg)
                st.success("Saved monthly and category budget limits to data/budget_config.json!")
                st.rerun()

        st.divider()
        st.subheader("Create Your Own Category")
        with st.form("custom_cat_form", clear_on_submit=True):
            cc1, cc2, cc3 = st.columns([2.5, 1.2, 1])
            with cc1:
                custom_name = st.text_input("Category Name", placeholder="e.g. Party Supplies")
            with cc2:
                custom_budget = st.number_input("Monthly Limit ($)", min_value=1.0, value=35.0, step=5.0)
            with cc3:
                custom_color = st.color_picker("Color", "#ec4899")

            if st.form_submit_button("Add Category"):
                cleaned_name = custom_name.strip()
                if len(cleaned_name) < 2:
                    st.error("Category name must be at least 2 characters.")
                elif any(c.lower() == cleaned_name.lower() for c in all_categories):
                    st.error(f'Category "{cleaned_name}" already exists.')
                else:
                    customs = list(raw_cfg.get("customCategories", []))  # type: ignore[arg-type]
                    customs.append(
                        {
                            "name": cleaned_name,
                            "color": custom_color,
                            "budget": round(custom_budget, 2),
                        }
                    )
                    raw_cfg["customCategories"] = customs
                    cat_budgets = dict(raw_cfg.get("categoryBudgets", {}))  # type: ignore[arg-type]
                    cat_budgets[cleaned_name] = round(custom_budget, 2)
                    raw_cfg["categoryBudgets"] = cat_budgets
                    save_raw_budget_config(raw_cfg)
                    st.success(f'Added custom category "{cleaned_name}"!')
                    st.rerun()

    with tab_reports:
        st.subheader("Export Reports & Matplotlib Charts")
        c_dl1, c_dl2 = st.columns(2)
        with c_dl1:
            st.download_button(
                "Download Grocery List (CSV)",
                data=records_to_csv_bytes(records),
                file_name="spendbasket_groceries.csv",
                mime="text/csv",
                use_container_width=True,
            )

        md_path = export_markdown_report(records, config, DATA_DIR / "executive_summary.md")
        md_text = md_path.read_text(encoding="utf-8")
        with c_dl2:
            st.download_button(
                "Download Executive Summary (Markdown)",
                data=md_text.encode("utf-8"),
                file_name="spendbasket_summary.md",
                mime="text/markdown",
                use_container_width=True,
            )

        if st.button("Generate Matplotlib Chart Report"):
            generated = generate_budget_charts(records, config, DATA_DIR / "charts")
            for p in generated:
                if p.suffix == ".png":
                    st.image(str(p), caption="Category Spend vs. Fixed Budget (Matplotlib)")
                else:
                    st.code(p.read_text(encoding="utf-8"))

        st.markdown("#### Markdown Summary Preview")
        st.markdown(md_text)


if __name__ == "__main__":
    main()
