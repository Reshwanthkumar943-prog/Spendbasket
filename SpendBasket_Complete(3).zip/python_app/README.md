# SpendBasket — Python Streamlit UI, Web Server & CLI Suite

Standalone Python 3.10+ **Streamlit web interface**, HTTP web server, interactive terminal assistant, and reporting suite for **SpendBasket (Grocery Budget Assistant)**.

## 1. Run the Python Streamlit Interface (Recommended)
Install dependencies once:
```bash
pip install -r python_app/requirements.txt
```
Launch the Streamlit web app:
```bash
streamlit run python_app/streamlit_app.py
```
*(Or `python3 -m streamlit run python_app/streamlit_app.py`)*

## 2. Run the Zero-Dependency Python Web Server
```bash
python3 python_app/web_server.py
```
Then open **`http://localhost:8000`** in your browser.

## 3. Run the Interactive Python CLI
```bash
python3 python_app/main.py
```

## 4. Run Automated Unit & API Tests
```bash
python3 -m unittest discover -s python_app -v
```
