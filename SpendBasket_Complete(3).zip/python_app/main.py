"""Interactive terminal entry point for Grocery Budget Assistant."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from analytics import compute_executive_summary, export_markdown_report
from charts import generate_budget_charts
from models import GroceryRecord
from storage import (
    DATA_DIR,
    bulk_import_csv,
    load_budget_config,
    load_records,
    save_records,
)
from validator import (
    prompt_category,
    prompt_non_empty_text,
    prompt_positive_float,
    prompt_valid_date,
)

GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"


def print_banner() -> None:
    print(f"\n{BOLD}=== SPENDBASKET | GROCERY BUDGET ASSISTANT (PYTHON CLI) ==={RESET}")


def print_table(records: list[GroceryRecord], page_size: int = 12) -> None:
    if not records:
        print("No grocery records stored yet.")
        return
    header = (
        f"{'ID':<9} {'Item':<26} {'Category':<15} {'Qty':>5} "
        f"{'Total':>9} {'Cap':>9} {'Status':<13} {'Date':<10}"
    )
    print("-" * len(header))
    print(header)
    print("-" * len(header))
    for idx, r in enumerate(records, start=1):
        status = "OVER BUDGET" if r.total_cost > r.item_budget else "WITHIN"
        color = RED if status == "OVER BUDGET" else GREEN
        print(
            f"{r.id:<9} {r.item_name[:25]:<26} {r.category[:14]:<15} "
            f"{r.quantity:>5.1f} ${r.total_cost:>8.2f} ${r.item_budget:>8.2f} "
            f"{color}{status:<13}{RESET} {r.purchase_date:<10}"
        )
        if idx % page_size == 0 and idx < len(records):
            input(f"\n-- Showing {idx}/{len(records)} rows. Press Enter for next page --")


def main() -> None:
    records, notice = load_records()
    config = load_budget_config()
    if notice:
        print(f"{YELLOW}[Storage Notice] {notice}{RESET}")

    while True:
        print_banner()
        print("1. Add New Grocery Entry (with defensive validation)")
        print("2. View All Records (paginated ledger)")
        print("3. Search & Filter by Keyword or Category")
        print("4. Executive Summary & Overspending Flags")
        print("5. Export Reports (Markdown & Matplotlib Chart)")
        print("6. Bulk Import CSV with Row-by-Row Validation")
        print("7. Save & Exit")

        choice = input("\nSelect option (1-7): ").strip()
        if choice == "1":
            name = prompt_non_empty_text("Item Name")
            category = prompt_category()
            qty = prompt_positive_float("Quantity", 0.01, 10000.0)
            unit_price = prompt_positive_float("Unit Price ($)", 0.01, 100000.0)
            item_budget = prompt_positive_float("Fixed Item Budget ($)", 0.01, 100000.0)
            purchase_date = prompt_valid_date("Purchase Date")
            store = prompt_non_empty_text("Store Name", 2, 50)
            notes = input("Notes (optional): ").strip()[:160]

            total_cost = round(qty * unit_price, 2)
            rec_id = f"GRB-{1001 + len(records)}"
            rec = GroceryRecord(
                id=rec_id,
                item_name=name,
                category=category,
                quantity=qty,
                unit_price=unit_price,
                total_cost=total_cost,
                item_budget=item_budget,
                purchase_date=purchase_date,
                store=store,
                notes=notes,
                created_at=datetime.now(timezone.utc).isoformat(),
            )
            records.append(rec)
            save_records(records)
            flag = (
                f"{RED}[OVERSPENT by ${total_cost - item_budget:.2f}]{RESET}"
                if total_cost > item_budget
                else f"{GREEN}[WITHIN BUDGET]{RESET}"
            )
            print(f"Saved {rec.id} (${total_cost:.2f}) {flag}")
        elif choice == "2":
            print_table(records)
        elif choice == "3":
            kw = input("Keyword (item/store, blank for all): ").strip().lower()
            filtered = [
                r
                for r in records
                if kw in r.item_name.lower()
                or kw in r.store.lower()
                or kw in r.category.lower()
            ]
            print_table(filtered)
        elif choice == "4":
            summary = compute_executive_summary(records, config)
            print(
                f"\nTotal Spend: ${summary['total_spend']:.2f} / Fixed Budget: "
                f"${summary['overall_budget']:.2f} ({summary['overall_status']})"
            )
            print(
                f"Overspent Items Flagged: {summary['overspent_count']} / {summary['total_entries']}"
            )
        elif choice == "5":
            md_path = export_markdown_report(
                records, config, DATA_DIR / "executive_summary.md"
            )
            charts = generate_budget_charts(records, config, DATA_DIR / "charts")
            print(f"Exported Markdown: {md_path}")
            print(f"Generated Chart(s): {', '.join(str(p) for p in charts)}")
        elif choice == "6":
            csv_file = Path(input("Path to CSV file: ").strip())
            accepted, errs = bulk_import_csv(csv_file, records)
            records.extend(accepted)
            save_records(records)
            print(f"Imported {len(accepted)} rows; Rejected {len(errs)} rows.")
            for err in errs:
                print(f"  {RED}{err}{RESET}")
        elif choice == "7":
            save_records(records)
            print("All records persisted to JSON and CSV. Goodbye!")
            break
        else:
            print(f"{YELLOW}Invalid option. Enter 1-7.{RESET}")


if __name__ == "__main__":
    main()
