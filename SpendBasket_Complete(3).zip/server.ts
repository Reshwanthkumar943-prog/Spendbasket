import express from 'express';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  DEFAULT_BUDGET_CONFIG,
  LEGACY_CATEGORY_MIGRATION,
  SEED_GROCERY_RECORDS,
} from './src/data/seedData.ts';
import {
  BUILT_IN_CATEGORIES,
  type BudgetConfig,
  type CustomCategoryDef,
  type GroceryRecord,
} from './src/types/grocery.ts';
import { sanitizeText, validateGroceryInput } from './src/utils/validation.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, 'data');
const RECORDS_JSON_PATH = path.join(DATA_DIR, 'grocery_records.json');
const RECORDS_CSV_PATH = path.join(DATA_DIR, 'grocery_records.csv');
const CONFIG_JSON_PATH = path.join(DATA_DIR, 'budget_config.json');

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function serializeCsv(records: GroceryRecord[]): string {
  const header =
    'id,item_name,category,quantity,unit_price,total_cost,item_budget,purchase_date,store,notes,created_at';
  const esc = (v: string) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const rows = records.map((r) =>
    [
      esc(r.id),
      esc(r.itemName),
      esc(r.category),
      r.quantity.toFixed(2),
      r.unitPrice.toFixed(2),
      r.totalCost.toFixed(2),
      r.itemBudget.toFixed(2),
      esc(r.purchaseDate),
      esc(r.store),
      esc(r.notes),
      esc(r.createdAt),
    ].join(',')
  );
  return [header, ...rows].join('\n');
}

function saveRecordsToDisk(records: GroceryRecord[]): void {
  ensureDataDir();
  fs.writeFileSync(RECORDS_JSON_PATH, JSON.stringify(records, null, 2), 'utf-8');
  fs.writeFileSync(RECORDS_CSV_PATH, serializeCsv(records), 'utf-8');
}

function saveConfigToDisk(config: BudgetConfig): void {
  ensureDataDir();
  fs.writeFileSync(CONFIG_JSON_PATH, JSON.stringify(config, null, 2), 'utf-8');
}

function loadRecordsFromDisk(): GroceryRecord[] {
  ensureDataDir();
  if (!fs.existsSync(RECORDS_JSON_PATH)) {
    const seeded = [...SEED_GROCERY_RECORDS];
    saveRecordsToDisk(seeded);
    return seeded;
  }

  try {
    const raw = fs.readFileSync(RECORDS_JSON_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      throw new Error('Root JSON structure is not an array');
    }
    let migrated = false;
    const sanitizedList: GroceryRecord[] = parsed
      .map((rawItem: Record<string, unknown>): GroceryRecord | null => {
        if (!rawItem || typeof rawItem !== 'object') return null;
        const id = typeof rawItem.id === 'string' ? rawItem.id : '';
        const itemName = String(rawItem.itemName ?? rawItem.item_name ?? '');
        const rawCategory = String(rawItem.category ?? '');
        const category = LEGACY_CATEGORY_MIGRATION[rawCategory] ?? rawCategory;
        const quantity = Number(rawItem.quantity ?? 0);
        const unitPrice = Number(rawItem.unitPrice ?? rawItem.unit_price ?? 0);
        const totalCost = Number(rawItem.totalCost ?? rawItem.total_cost ?? 0);
        const itemBudget = Number(rawItem.itemBudget ?? rawItem.item_budget ?? 0);
        const purchaseDate = String(rawItem.purchaseDate ?? rawItem.purchase_date ?? '');
        const store = String(rawItem.store ?? '');
        const notes = String(rawItem.notes ?? '');
        const createdAt = String(rawItem.createdAt ?? rawItem.created_at ?? '');

        if (!id || !itemName || !Number.isFinite(totalCost)) return null;
        if (rawCategory in LEGACY_CATEGORY_MIGRATION || 'item_name' in rawItem) {
          migrated = true;
        }
        return {
          id,
          itemName,
          category,
          quantity,
          unitPrice,
          totalCost,
          itemBudget,
          purchaseDate,
          store,
          notes,
          createdAt,
        };
      })
      .filter((item): item is GroceryRecord => item !== null);

    if (migrated || !fs.existsSync(RECORDS_CSV_PATH)) {
      saveRecordsToDisk(sanitizedList);
    }
    return sanitizedList;
  } catch {
    const cleanSeed = [...SEED_GROCERY_RECORDS];
    saveRecordsToDisk(cleanSeed);
    return cleanSeed;
  }
}

function loadConfigFromDisk(): BudgetConfig {
  ensureDataDir();
  if (!fs.existsSync(CONFIG_JSON_PATH)) {
    saveConfigToDisk(DEFAULT_BUDGET_CONFIG);
    return { ...DEFAULT_BUDGET_CONFIG };
  }

  try {
    const raw = fs.readFileSync(CONFIG_JSON_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<BudgetConfig>;
    const overall =
      typeof parsed.overallMonthlyBudget === 'number' && parsed.overallMonthlyBudget > 0
        ? parsed.overallMonthlyBudget
        : DEFAULT_BUDGET_CONFIG.overallMonthlyBudget;
    const warning =
      typeof parsed.warningThresholdPct === 'number' &&
      parsed.warningThresholdPct >= 50 &&
      parsed.warningThresholdPct <= 99
        ? parsed.warningThresholdPct
        : DEFAULT_BUDGET_CONFIG.warningThresholdPct;

    const categoryBudgets: Record<string, number> = {
      ...DEFAULT_BUDGET_CONFIG.categoryBudgets,
    };

    if (parsed.categoryBudgets && typeof parsed.categoryBudgets === 'object') {
      for (const [k, v] of Object.entries(parsed.categoryBudgets)) {
        const mappedKey = LEGACY_CATEGORY_MIGRATION[k] ?? k;
        if (typeof v === 'number' && v > 0) {
          categoryBudgets[mappedKey] = v;
        }
      }
    }

    const customCategories: CustomCategoryDef[] = Array.isArray(parsed.customCategories)
      ? parsed.customCategories.filter(
          (c): c is CustomCategoryDef =>
            Boolean(c) &&
            typeof c.name === 'string' &&
            typeof c.color === 'string' &&
            typeof c.budget === 'number' &&
            c.budget > 0
        )
      : [];

    for (const c of customCategories) {
      if (!(c.name in categoryBudgets)) {
        categoryBudgets[c.name] = c.budget;
      }
    }

    return {
      overallMonthlyBudget: overall,
      warningThresholdPct: warning,
      categoryBudgets,
      customCategories,
    };
  } catch {
    saveConfigToDisk(DEFAULT_BUDGET_CONFIG);
    return { ...DEFAULT_BUDGET_CONFIG };
  }
}

const ZIP_IGNORED_DIRS = new Set([
  'node_modules',
  '.git',
  '__pycache__',
  '.aistudio',
]);

function addDirectoryToZip(zip: JSZip, rootDir: string, currentRel: string): void {
  const fullDir = path.join(rootDir, currentRel);
  const entries = fs.readdirSync(fullDir, { withFileTypes: true });
  for (const entry of entries) {
    if (ZIP_IGNORED_DIRS.has(entry.name)) continue;
    if (entry.name.endsWith('.bak') || entry.name.endsWith('.pyc')) continue;
    if (entry.name === 'public' && currentRel === '') {
      // Skip large attached PDFs in public/assets when bundling clean code zip
      continue;
    }

    const relPath = currentRel ? `${currentRel}/${entry.name}` : entry.name;
    const absPath = path.join(rootDir, relPath);

    if (entry.isDirectory()) {
      addDirectoryToZip(zip, rootDir, relPath);
    } else if (entry.isFile()) {
      zip.file(relPath, fs.readFileSync(absPath));
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  loadRecordsFromDisk();
  loadConfigFromDisk();

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/state', (_req, res) => {
    const records = loadRecordsFromDisk();
    const budgetConfig = loadConfigFromDisk();
    res.json({ records, budgetConfig });
  });

  app.get('/api/download-zip', async (_req, res) => {
    try {
      const zip = new JSZip();
      addDirectoryToZip(zip, __dirname, '');
      const buffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="SpendBasket_Complete.zip"'
      );
      res.send(buffer);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to build zip archive.',
      });
    }
  });

  app.post('/api/records', (req, res) => {
    const config = loadConfigFromDisk();
    const allowed = [
      ...BUILT_IN_CATEGORIES,
      ...config.customCategories.map((c) => c.name),
    ];
    const validation = validateGroceryInput(req.body ?? {}, allowed);
    if (!validation.valid || !validation.sanitized) {
      res.status(400).json({ error: 'Validation failed', errors: validation.errors });
      return;
    }

    const records = loadRecordsFromDisk();
    const existingIds = new Set(records.map((r) => r.id));
    let nextNum = 1001 + records.length;
    while (existingIds.has(`GRB-${nextNum}`)) {
      nextNum++;
    }

    const newRecord: GroceryRecord = {
      id: `GRB-${nextNum}`,
      ...validation.sanitized,
      createdAt: new Date().toISOString(),
    };

    const updated = [newRecord, ...records];
    saveRecordsToDisk(updated);
    res.status(201).json({ record: newRecord, records: updated });
  });

  app.put('/api/records/:id', (req, res) => {
    const { id } = req.params;
    const config = loadConfigFromDisk();
    const allowed = [
      ...BUILT_IN_CATEGORIES,
      ...config.customCategories.map((c) => c.name),
    ];
    const validation = validateGroceryInput(req.body ?? {}, allowed);
    if (!validation.valid || !validation.sanitized) {
      res.status(400).json({ error: 'Validation failed', errors: validation.errors });
      return;
    }

    const records = loadRecordsFromDisk();
    const index = records.findIndex((r) => r.id === id);
    if (index === -1) {
      res.status(404).json({ error: `Item ${id} not found` });
      return;
    }

    const updatedRecord: GroceryRecord = {
      ...records[index],
      ...validation.sanitized,
    };
    const updated = [...records];
    updated[index] = updatedRecord;
    saveRecordsToDisk(updated);

    res.json({ record: updatedRecord, records: updated });
  });

  app.delete('/api/records/:id', (req, res) => {
    const { id } = req.params;
    const records = loadRecordsFromDisk();
    const updated = records.filter((r) => r.id !== id);
    if (updated.length === records.length) {
      res.status(404).json({ error: `Item ${id} not found` });
      return;
    }
    saveRecordsToDisk(updated);
    res.json({ records: updated });
  });

  app.put('/api/budget', (req, res) => {
    const body = req.body ?? {};
    const overall = Number(body.overallMonthlyBudget);
    const warning = Number(body.warningThresholdPct ?? 85);

    if (!Number.isFinite(overall) || overall < 1 || overall > 1000000) {
      res.status(400).json({ error: 'Monthly budget must be at least $1.00.' });
      return;
    }
    if (!Number.isFinite(warning) || warning < 50 || warning > 99) {
      res.status(400).json({ error: 'Warning threshold must be between 50% and 99%.' });
      return;
    }

    const current = loadConfigFromDisk();
    const nextCategoryBudgets = { ...current.categoryBudgets };
    if (body.categoryBudgets && typeof body.categoryBudgets === 'object') {
      for (const [cat, rawVal] of Object.entries(body.categoryBudgets)) {
        const val = Number(rawVal);
        if (!Number.isFinite(val) || val < 1 || val > 500000) {
          res.status(400).json({ error: `Budget for ${cat} must be at least $1.00.` });
          return;
        }
        nextCategoryBudgets[cat] = Math.round(val * 100) / 100;
      }
    }

    const customCategories = Array.isArray(body.customCategories)
      ? body.customCategories
      : current.customCategories;

    const nextConfig: BudgetConfig = {
      overallMonthlyBudget: Math.round(overall * 100) / 100,
      warningThresholdPct: Math.round(warning),
      categoryBudgets: nextCategoryBudgets,
      customCategories,
    };

    saveConfigToDisk(nextConfig);
    res.json({ budgetConfig: nextConfig });
  });

  app.post('/api/categories', (req, res) => {
    const name = sanitizeText(String(req.body?.name ?? ''));
    const color = sanitizeText(String(req.body?.color ?? '#10b981'));
    const budget = Number(req.body?.budget);

    if (!name || name.length < 2 || name.length > 40) {
      res.status(400).json({ error: 'Category name must be between 2 and 40 characters.' });
      return;
    }
    if (!Number.isFinite(budget) || budget < 1 || budget > 500000) {
      res.status(400).json({ error: 'Category budget must be at least $1.00.' });
      return;
    }

    const current = loadConfigFromDisk();
    const existsBuiltIn = BUILT_IN_CATEGORIES.some(
      (c) => c.toLowerCase() === name.toLowerCase()
    );
    const existsCustom = current.customCategories.some(
      (c) => c.name.toLowerCase() === name.toLowerCase()
    );
    if (existsBuiltIn || existsCustom) {
      res.status(400).json({ error: `Category "${name}" already exists.` });
      return;
    }

    const nextConfig: BudgetConfig = {
      ...current,
      customCategories: [
        ...current.customCategories,
        {
          name,
          color: /^#[0-9a-fA-F]{6}$/.test(color) ? color : '#10b981',
          budget: Math.round(budget * 100) / 100,
        },
      ],
      categoryBudgets: {
        ...current.categoryBudgets,
        [name]: Math.round(budget * 100) / 100,
      },
    };
    saveConfigToDisk(nextConfig);
    res.status(201).json({ budgetConfig: nextConfig });
  });

  app.delete('/api/categories/:name', (req, res) => {
    const target = decodeURIComponent(req.params.name);
    const current = loadConfigFromDisk();
    const nextCustom = current.customCategories.filter(
      (c) => c.name.toLowerCase() !== target.toLowerCase()
    );
    const nextBudgets = { ...current.categoryBudgets };
    delete nextBudgets[target];

    const nextConfig: BudgetConfig = {
      ...current,
      customCategories: nextCustom,
      categoryBudgets: nextBudgets,
    };
    saveConfigToDisk(nextConfig);
    res.json({ budgetConfig: nextConfig });
  });

  app.post('/api/reset', (req, res) => {
    const mode = req.body?.mode === 'empty' ? 'empty' : 'seed';
    const nextRecords = mode === 'empty' ? [] : [...SEED_GROCERY_RECORDS];
    const nextConfig = { ...DEFAULT_BUDGET_CONFIG };
    saveRecordsToDisk(nextRecords);
    saveConfigToDisk(nextConfig);
    res.json({ records: nextRecords, budgetConfig: nextConfig });
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SpendBasket server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
