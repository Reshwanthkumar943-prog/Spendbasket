# SpendBasket — Grocery Budget Assistant

A colorful, modern grocery budget assistant featuring:
1. **Python Streamlit Web Interface (`python_app/streamlit_app.py`)**
2. **Zero-Dependency Python Web Server (`python_app/web_server.py`)**
3. **Interactive Python CLI & Matplotlib Suite (`python_app/main.py`)**
4. **React + TypeScript Web Frontend (`src/` + `server.ts`)**

All interfaces share the same local JSON & CSV database in `data/`.

## Quick Start in VS Code

### Option 1: Python Streamlit Interface (Pure Python UI)
```bash
pip install -r python_app/requirements.txt
streamlit run python_app/streamlit_app.py
```

### Option 2: Zero-Dependency Python Web Server
```bash
python3 python_app/web_server.py
```
Open **`http://localhost:8000`** in your browser.

### Option 3: Interactive Python CLI & Tests
```bash
python3 python_app/main.py
python3 -m unittest discover -s python_app -v
```
