import { useCallback, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { CheckCircle2, Download, XOctagon } from 'lucide-react';
import { CategoriesView } from './components/CategoriesView.tsx';
import { EntryModal } from './components/EntryModal.tsx';
import { GroceriesView } from './components/GroceriesView.tsx';
import { OverviewView } from './components/OverviewView.tsx';
import { TopNav, type AppTab } from './components/TopNav.tsx';
import { DEFAULT_BUDGET_CONFIG } from './data/seedData.ts';
import type {
  BudgetConfig,
  FieldValidationError,
  GroceryRecord,
  GroceryRecordInput,
} from './types/grocery.ts';
import { buildExecutiveSummary, evaluateRecords } from './utils/analytics.ts';

interface ToastState {
  id: number;
  tone: 'ok' | 'warn';
  text: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('overview');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');

  const [records, setRecords] = useState<GroceryRecord[]>([]);
  const [budgetConfig, setBudgetConfig] = useState<BudgetConfig>(DEFAULT_BUDGET_CONFIG);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<GroceryRecord | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = (tone: 'ok' | 'warn', text: string) => {
    const id = Date.now();
    setToast({ id, tone, text });
    setTimeout(() => {
      setToast((curr) => (curr?.id === id ? null : curr));
    }, 3200);
  };

  const fetchState = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch('/api/state');
      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }
      const data = await res.json();
      setRecords(data.records ?? []);
      setBudgetConfig(data.budgetConfig ?? DEFAULT_BUDGET_CONFIG);
    } catch (err) {
      setLoadError(
        err instanceof Error ? err.message : 'Unable to load your grocery budget.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const evaluatedRecords = useMemo(
    () => evaluateRecords(records, budgetConfig),
    [records, budgetConfig]
  );

  const summary = useMemo(
    () => buildExecutiveSummary(records, budgetConfig),
    [records, budgetConfig]
  );

  const handleSaveEntry = async (
    payload: GroceryRecordInput,
    editingId?: string
  ): Promise<{
    ok: boolean;
    errors?: FieldValidationError[];
    serverError?: string;
  }> => {
    const endpoint = editingId ? `/api/records/${editingId}` : '/api/records';
    const method = editingId ? 'PUT' : 'POST';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          ok: false,
          errors: data.errors,
          serverError: data.error ?? 'Could not save purchase.',
        };
      }
      setRecords(data.records);

      const saved: GroceryRecord = data.record;
      if (saved.totalCost > saved.itemBudget) {
        showToast(
          'warn',
          `${saved.itemName} ($${saved.totalCost.toFixed(2)}) is over its $${saved.itemBudget.toFixed(2)} target.`
        );
      } else {
        showToast('ok', `Saved ${saved.itemName} ($${saved.totalCost.toFixed(2)}).`);
      }
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        serverError: err instanceof Error ? err.message : 'Network error while saving.',
      };
    }
  };

  const handleDeleteEntry = async (id: string) => {
    try {
      const res = await fetch(`/api/records/${id}`, { method: 'DELETE' });
      if (!res.ok) return;
      const data = await res.json();
      setRecords(data.records);
      showToast('ok', 'Item removed from your grocery list.');
    } catch {
      // ignore transient error
    }
  };

  const handleSaveBudgetConfig = async (
    next: BudgetConfig
  ): Promise<{ ok: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/budget', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(next),
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, error: data.error ?? 'Could not save budget limits.' };
      }
      setBudgetConfig(data.budgetConfig);
      showToast('ok', 'Budget limits updated.');
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : 'Network error while saving.',
      };
    }
  };

  const handleCreateCustomCategory = async (payload: {
    name: string;
    color: string;
    budget: number;
  }): Promise<{ ok: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, error: data.error ?? 'Could not create category.' };
      }
      setBudgetConfig(data.budgetConfig);
      showToast('ok', `Added custom category "${payload.name}".`);
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : 'Network error.',
      };
    }
  };

  const handleDeleteCustomCategory = async (name: string) => {
    const res = await fetch(`/api/categories/${encodeURIComponent(name)}`, {
      method: 'DELETE',
    });
    if (!res.ok) return;
    const data = await res.json();
    setBudgetConfig(data.budgetConfig);
    showToast('ok', `Removed "${name}".`);
  };

  const handleResetSampleData = async (mode: 'seed' | 'empty') => {
    const res = await fetch('/api/reset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode }),
    });
    if (!res.ok) return;
    const data = await res.json();
    setRecords(data.records);
    setBudgetConfig(data.budgetConfig);
    showToast(
      'ok',
      mode === 'empty' ? 'Cleared all grocery items.' : 'Restored sample grocery month.'
    );
  };

  const openAddModal = () => {
    setEditingRecord(null);
    setModalOpen(true);
  };

  const openEditModal = (rec: GroceryRecord) => {
    setEditingRecord(rec);
    setModalOpen(true);
  };

  const handleOpenCategory = (category: string) => {
    setSelectedCategoryFilter(category);
    setActiveTab('groceries');
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col workspace-backdrop text-slate-900">
        <TopNav
          activeTab={activeTab}
          onSelectTab={(tab) => {
            if (tab === 'groceries') setSelectedCategoryFilter('All');
            setActiveTab(tab);
          }}
          onOpenAddModal={openAddModal}
        />

        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
          {loading ? (
            <div className="space-y-6" aria-busy="true" aria-label="Loading groceries">
              <div className="h-48 bg-white border border-slate-200 rounded-2xl animate-pulse" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="h-72 bg-white border border-slate-200 rounded-2xl animate-pulse" />
                <div className="h-72 bg-white border border-slate-200 rounded-2xl animate-pulse" />
              </div>
            </div>
          ) : loadError ? (
            <div className="bg-white border border-rose-200 rounded-2xl p-6 space-y-3">
              <h2 className="font-display text-base font-semibold text-rose-800">
                Unable to Load Grocery Data
              </h2>
              <p className="text-sm text-slate-600">{loadError}</p>
              <button
                type="button"
                onClick={fetchState}
                className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-medium cursor-pointer"
              >
                Try Again
              </button>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              >
                {activeTab === 'overview' && (
                  <OverviewView
                    summary={summary}
                    recentRecords={evaluatedRecords}
                    config={budgetConfig}
                    onOpenCategory={handleOpenCategory}
                    onSeeAllGroceries={() => {
                      setSelectedCategoryFilter('All');
                      setActiveTab('groceries');
                    }}
                    onOpenAddModal={openAddModal}
                  />
                )}

                {activeTab === 'groceries' && (
                  <GroceriesView
                    key={selectedCategoryFilter}
                    records={evaluatedRecords}
                    config={budgetConfig}
                    initialCategory={selectedCategoryFilter}
                    onEdit={openEditModal}
                    onDelete={handleDeleteEntry}
                    onOpenAddModal={openAddModal}
                  />
                )}

                {activeTab === 'categories' && (
                  <CategoriesView
                    config={budgetConfig}
                    summary={summary}
                    onSaveConfig={handleSaveBudgetConfig}
                    onCreateCustomCategory={handleCreateCustomCategory}
                    onDeleteCustomCategory={handleDeleteCustomCategory}
                    onOpenCategoryItems={handleOpenCategory}
                    onResetSampleData={handleResetSampleData}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          )}
        </main>

        <EntryModal
          isOpen={modalOpen}
          editingRecord={editingRecord}
          config={budgetConfig}
          onClose={() => setModalOpen(false)}
          onSubmit={handleSaveEntry}
        />

        <footer className="border-t border-slate-200/80 bg-white/60">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
            <span>SpendBasket · Grocery Budget Assistant</span>
            <a
              href="/api/download-zip"
              download="SpendBasket_Complete.zip"
              className="inline-flex items-center gap-1.5 font-medium text-emerald-700 hover:text-emerald-800 underline underline-offset-2"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Download Project (.zip)</span>
            </a>
          </div>
        </footer>

        {/* Animated Save Feedback Toast */}
        <AnimatePresence>
          {toast && (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.96 }}
              transition={{ duration: 0.18 }}
              className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg border text-xs font-medium flex items-center gap-2.5 ${
                toast.tone === 'warn'
                  ? 'bg-rose-950 text-rose-50 border-rose-800'
                  : 'bg-emerald-950 text-emerald-50 border-emerald-800'
              }`}
              role="status"
            >
              {toast.tone === 'warn' ? (
                <XOctagon className="w-4 h-4 text-rose-400 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
              <span>{toast.text}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
