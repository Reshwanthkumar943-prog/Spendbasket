import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AlertCircle, X } from 'lucide-react';
import type {
  BudgetConfig,
  FieldValidationError,
  GroceryRecord,
  GroceryRecordInput,
} from '../types/grocery.ts';
import { getAllCategoryNames } from '../utils/analytics.ts';
import { getCategoryVisual } from '../utils/categoryColors.ts';
import { validateGroceryInput } from '../utils/validation.ts';

interface EntryModalProps {
  isOpen: boolean;
  editingRecord: GroceryRecord | null;
  config: BudgetConfig;
  onClose: () => void;
  onSubmit: (
    payload: GroceryRecordInput,
    editingId?: string
  ) => Promise<{
    ok: boolean;
    errors?: FieldValidationError[];
    serverError?: string;
  }>;
}

const TODAY_ISO = new Date().toISOString().slice(0, 10);

export function EntryModal({
  isOpen,
  editingRecord,
  config,
  onClose,
  onSubmit,
}: EntryModalProps) {
  const categoryNames = getAllCategoryNames(config);

  const [itemName, setItemName] = useState('');
  const [category, setCategory] = useState<string>('Fresh Fruits & Veggies');
  const [quantity, setQuantity] = useState('1');
  const [unitPrice, setUnitPrice] = useState('');
  const [itemBudget, setItemBudget] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(TODAY_ISO);
  const [store, setStore] = useState('FreshMarket');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<FieldValidationError[]>([]);
  const [serverError, setServerError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    if (editingRecord) {
      setItemName(editingRecord.itemName);
      setCategory(editingRecord.category);
      setQuantity(String(editingRecord.quantity));
      setUnitPrice(String(editingRecord.unitPrice));
      setItemBudget(String(editingRecord.itemBudget));
      setPurchaseDate(editingRecord.purchaseDate);
      setStore(editingRecord.store);
      setNotes(editingRecord.notes);
    } else {
      setItemName('');
      setCategory('Fresh Fruits & Veggies');
      setQuantity('1');
      setUnitPrice('');
      setItemBudget('');
      setPurchaseDate(TODAY_ISO);
      setStore('FreshMarket');
      setNotes('');
    }
    setErrors([]);
    setServerError(null);
  }, [isOpen, editingRecord]);

  const qtyNum = Number(quantity);
  const priceNum = Number(unitPrice);
  const budgetNum = Number(itemBudget);
  const computedCost =
    Number.isFinite(qtyNum) && Number.isFinite(priceNum) && qtyNum > 0 && priceNum > 0
      ? Math.round(qtyNum * priceNum * 100) / 100
      : null;
  const projectedVariance =
    computedCost !== null && Number.isFinite(budgetNum) && budgetNum > 0
      ? Math.round((budgetNum - computedCost) * 100) / 100
      : null;

  const fieldError = (field: string) =>
    errors.find((e) => e.field === field)?.message;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError(null);

    const payload: GroceryRecordInput = {
      itemName,
      category,
      quantity,
      unitPrice,
      itemBudget,
      purchaseDate,
      store,
      notes,
    };

    const clientCheck = validateGroceryInput(payload, categoryNames);
    if (!clientCheck.valid) {
      setErrors(clientCheck.errors);
      return;
    }

    setErrors([]);
    setSubmitting(true);
    try {
      const result = await onSubmit(payload, editingRecord?.id);
      if (!result.ok) {
        if (result.errors) setErrors(result.errors);
        if (result.serverError) setServerError(result.serverError);
        return;
      }
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 backdrop-blur-xs p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="entry-modal-title"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ type: 'spring', stiffness: 380, damping: 28 }}
            className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl"
          >
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4 bg-gradient-to-r from-emerald-50 via-white to-sky-50">
              <h2
                id="entry-modal-title"
                className="font-display text-base font-bold text-slate-900"
              >
                {editingRecord ? 'Update Grocery Purchase' : 'Log a Grocery Purchase'}
              </h2>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-5" noValidate>
              {serverError && (
                <div className="p-3 rounded-xl border border-rose-200 bg-rose-50 text-xs text-rose-800 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{serverError}</span>
                </div>
              )}

              {/* Visual Category Picker Grid */}
              <div>
                <span className="block text-xs font-medium text-slate-700 mb-2">
                  Pick a Category
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
                  {categoryNames.map((cat) => {
                    const visual = getCategoryVisual(cat, config);
                    const Icon = visual.icon;
                    const selected = category === cat;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setCategory(cat)}
                        style={
                          selected
                            ? {
                                borderColor: visual.hex,
                                backgroundColor: `${visual.hex}14`,
                              }
                            : undefined
                        }
                        className={`flex items-center gap-2 px-2.5 py-2 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
                          selected
                            ? 'text-slate-900 shadow-xs'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <span
                          className="w-6 h-6 rounded-md flex items-center justify-center shrink-0"
                          style={{
                            backgroundColor: `${visual.hex}20`,
                            color: visual.hex,
                          }}
                        >
                          <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                        </span>
                        <span className="truncate">{cat}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label htmlFor="item-name" className="block text-xs font-medium text-slate-700 mb-1">
                    What did you buy?
                  </label>
                  <input
                    id="item-name"
                    type="text"
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    placeholder="e.g. Honeycrisp Apples, Oat Milk, Sourdough Bread"
                    className={`w-full px-3.5 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 ${
                      fieldError('itemName') ? 'border-rose-400' : 'border-slate-300 focus:border-emerald-700'
                    }`}
                  />
                  {fieldError('itemName') && (
                    <p className="mt-1 text-xs text-rose-600">{fieldError('itemName')}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="quantity" className="block text-xs font-medium text-slate-700 mb-1">
                    How many?
                  </label>
                  <input
                    id="quantity"
                    type="number"
                    step="0.01"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className={`w-full px-3.5 py-2 text-sm font-mono tabular-nums rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 ${
                      fieldError('quantity') ? 'border-rose-400' : 'border-slate-300 focus:border-emerald-700'
                    }`}
                  />
                  {fieldError('quantity') && (
                    <p className="mt-1 text-xs text-rose-600">{fieldError('quantity')}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="unit-price" className="block text-xs font-medium text-slate-700 mb-1">
                    Price each ($)
                  </label>
                  <input
                    id="unit-price"
                    type="number"
                    step="0.01"
                    value={unitPrice}
                    onChange={(e) => setUnitPrice(e.target.value)}
                    placeholder="4.50"
                    className={`w-full px-3.5 py-2 text-sm font-mono tabular-nums rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 ${
                      fieldError('unitPrice') ? 'border-rose-400' : 'border-slate-300 focus:border-emerald-700'
                    }`}
                  />
                  {fieldError('unitPrice') && (
                    <p className="mt-1 text-xs text-rose-600">{fieldError('unitPrice')}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="item-budget" className="block text-xs font-medium text-slate-700 mb-1">
                    Target Budget for This Item ($)
                  </label>
                  <input
                    id="item-budget"
                    type="number"
                    step="0.01"
                    value={itemBudget}
                    onChange={(e) => setItemBudget(e.target.value)}
                    placeholder="10.00"
                    className={`w-full px-3.5 py-2 text-sm font-mono tabular-nums rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 ${
                      fieldError('itemBudget') ? 'border-rose-400' : 'border-slate-300 focus:border-emerald-700'
                    }`}
                  />
                  {fieldError('itemBudget') && (
                    <p className="mt-1 text-xs text-rose-600">{fieldError('itemBudget')}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="purchase-date" className="block text-xs font-medium text-slate-700 mb-1">
                    Shopping Date
                  </label>
                  <input
                    id="purchase-date"
                    type="date"
                    value={purchaseDate}
                    onChange={(e) => setPurchaseDate(e.target.value)}
                    className={`w-full px-3.5 py-2 text-sm font-mono rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 ${
                      fieldError('purchaseDate') ? 'border-rose-400' : 'border-slate-300 focus:border-emerald-700'
                    }`}
                  />
                  {fieldError('purchaseDate') && (
                    <p className="mt-1 text-xs text-rose-600">{fieldError('purchaseDate')}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="store" className="block text-xs font-medium text-slate-700 mb-1">
                    Store
                  </label>
                  <input
                    id="store"
                    type="text"
                    value={store}
                    onChange={(e) => setStore(e.target.value)}
                    placeholder="FreshMarket"
                    className={`w-full px-3.5 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 ${
                      fieldError('store') ? 'border-rose-400' : 'border-slate-300 focus:border-emerald-700'
                    }`}
                  />
                  {fieldError('store') && (
                    <p className="mt-1 text-xs text-rose-600">{fieldError('store')}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="notes" className="block text-xs font-medium text-slate-700 mb-1">
                    Note (optional)
                  </label>
                  <input
                    id="notes"
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Dinner prep, snack pack..."
                    className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-700 focus:ring-2 focus:ring-emerald-600/20"
                  />
                </div>
              </div>

              {computedCost !== null && (
                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="text-slate-500">Total Cost: </span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      ${computedCost.toFixed(2)}
                    </span>
                  </div>
                  {projectedVariance !== null && (
                    <div className="font-mono tabular-nums">
                      {projectedVariance < 0 ? (
                        <span className="text-rose-700 font-semibold">
                          Over target by ${Math.abs(projectedVariance).toFixed(2)}
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-semibold">
                          Under target (+${projectedVariance.toFixed(2)} saved)
                        </span>
                      )}
                    </div>
                  )}
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 text-sm font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-60 text-white text-sm font-medium cursor-pointer"
                >
                  {submitting
                    ? 'Saving...'
                    : editingRecord
                      ? 'Save Changes'
                      : 'Add to My Groceries'}
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
