import { useState } from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, ArrowRight, Plus, XOctagon } from 'lucide-react';
import type {
  BudgetConfig,
  CategorySummary,
  EvaluatedRecord,
  ExecutiveSummary,
} from '../types/grocery.ts';
import { getCategoryVisual } from '../utils/categoryColors.ts';
import { AnimatedNumber } from './AnimatedNumber.tsx';
import { StatusLabel } from './StatusBadge.tsx';

interface OverviewViewProps {
  summary: ExecutiveSummary;
  recentRecords: EvaluatedRecord[];
  config: BudgetConfig;
  onOpenCategory: (category: string) => void;
  onSeeAllGroceries: () => void;
  onOpenAddModal: () => void;
}

export function OverviewView({
  summary,
  recentRecords,
  config,
  onOpenCategory,
  onSeeAllGroceries,
  onOpenAddModal,
}: OverviewViewProps) {
  const [hoveredSlice, setHoveredSlice] = useState<CategorySummary | null>(null);
  const [hoveredDateIdx, setHoveredDateIdx] = useState<number | null>(null);

  if (summary.totalEntries === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-4 shadow-xs"
      >
        <h1 className="font-display text-2xl font-bold text-slate-900">
          Start Tracking Your Monthly Groceries
        </h1>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          Add your first grocery trip to see colorful category breakdowns, spending trends, and instant budget alerts.
        </p>
        <div className="pt-2">
          <button
            type="button"
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-sm font-medium cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Log Your First Purchase</span>
          </button>
        </div>
      </motion.div>
    );
  }

  const isOverMonthly = summary.remainingBudget < 0;
  const isNearMonthly = summary.overallStatus === 'Near Limit';
  const heroGradient = isOverMonthly
    ? 'from-rose-600 via-red-600 to-orange-500'
    : isNearMonthly
      ? 'from-amber-500 via-orange-500 to-rose-500'
      : 'from-emerald-600 via-teal-600 to-sky-600';

  const progressPct = Math.min(100, summary.overallUtilizationPct);

  // Active categories with spend > 0 for Donut chart
  const activeSpendCats = summary.categories
    .filter((c) => c.totalSpend > 0)
    .sort((a, b) => b.totalSpend - a.totalSpend);

  const radius = 78;
  const circumference = 2 * Math.PI * radius;
  let cumulativeFraction = 0;

  // Trend curve coordinates
  const trendPoints = summary.dailyTrend;
  const maxTrendVal = Math.max(
    summary.overallBudget * 1.05,
    ...(trendPoints.length > 0 ? trendPoints.map((p) => p.cumulativeSpend) : [100])
  );
  const trendCoords = trendPoints.map((pt, i) => {
    const x =
      trendPoints.length === 1 ? 320 : 58 + (i / (trendPoints.length - 1)) * 548;
    const y = 212 - (pt.cumulativeSpend / maxTrendVal) * 175;
    return { x, y, pt };
  });
  const linePath =
    trendCoords.length > 0
      ? trendCoords
          .map((c, idx) => `${idx === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
          .join(' ')
      : '';
  const areaPath =
    trendCoords.length > 1
      ? `${linePath} L ${trendCoords[trendCoords.length - 1].x.toFixed(1)} 212 L ${trendCoords[0].x.toFixed(1)} 212 Z`
      : '';

  return (
    <div className="space-y-8">
      {/* Vibrant Animated Monthly Budget Hero Card */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        className={`rounded-2xl bg-gradient-to-br ${heroGradient} text-white p-6 sm:p-8 shadow-lg`}
        aria-label="Monthly grocery budget summary"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="text-sm font-medium text-white/85">
              Monthly Grocery Budget
            </div>
            <div className="flex flex-wrap items-baseline gap-3">
              <span className="font-mono text-4xl sm:text-5xl font-bold tracking-tight tabular-nums">
                <AnimatedNumber value={summary.totalSpend} prefix="$" />
              </span>
              <span className="font-mono text-lg text-white/80 tabular-nums">
                spent of ${summary.overallBudget.toFixed(0)}
              </span>
            </div>

            {/* Animated Progress Bar */}
            <div className="space-y-2 max-w-xl">
              <div className="h-3.5 w-full rounded-full bg-black/20 overflow-hidden p-0.5">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPct}%` }}
                  transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                  className="h-full rounded-full bg-white shadow-xs"
                />
              </div>
              <div className="flex items-center justify-between text-xs sm:text-sm text-white/90">
                <span>
                  {isOverMonthly
                    ? `You're $${Math.abs(summary.remainingBudget).toFixed(2)} over your monthly budget`
                    : `You have $${summary.remainingBudget.toFixed(2)} left to spend this month`}
                </span>
                <span className="font-mono font-semibold tabular-nums">
                  {summary.overallUtilizationPct.toFixed(0)}%
                </span>
              </div>
            </div>
          </div>

          {/* 3 Clean Glass Mini-Metrics */}
          <div className="lg:col-span-5 grid grid-cols-3 gap-3">
            <motion.div
              whileHover={{ y: -2 }}
              className="rounded-xl bg-white/15 backdrop-blur-xs border border-white/20 p-4"
            >
              <div className="text-xs text-white/80">Items Logged</div>
              <div className="mt-1 font-mono text-2xl font-bold tabular-nums">
                <AnimatedNumber value={summary.totalEntries} decimals={0} />
              </div>
            </motion.div>

            <motion.div
              whileHover={{ y: -2 }}
              className="rounded-xl bg-white/15 backdrop-blur-xs border border-white/20 p-4"
            >
              <div className="text-xs text-white/80">On Target</div>
              <div className="mt-1 font-mono text-2xl font-bold tabular-nums">
                <AnimatedNumber value={summary.complianceRatePct} decimals={0} suffix="%" />
              </div>
            </motion.div>

            <motion.div
              whileHover={{ y: -2 }}
              className="rounded-xl bg-white/15 backdrop-blur-xs border border-white/20 p-4"
            >
              <div className="text-xs text-white/80">Avg Trip</div>
              <div className="mt-1 font-mono text-2xl font-bold tabular-nums">
                <AnimatedNumber value={summary.averageEntryCost} prefix="$" decimals={0} />
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Friendly Overspending / Near-Limit Alerts */}
      {summary.warnings.length > 0 && (
        <section className="space-y-3" aria-label="Budget alerts">
          <h2 className="font-display text-base font-semibold text-slate-900">
            Heads Up on Your Spending
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {summary.warnings.slice(0, 3).map((w, idx) => (
              <motion.div
                key={w.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: 0.05 * idx }}
                className={`p-4 rounded-xl border text-xs flex items-start gap-3 ${
                  w.severity === 'critical'
                    ? 'border-rose-200 bg-rose-50/80 text-rose-950'
                    : 'border-amber-200 bg-amber-50/80 text-amber-950'
                }`}
              >
                {w.severity === 'critical' ? (
                  <XOctagon className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                )}
                <div className="min-w-0">
                  <div className="font-semibold text-sm">{w.title}</div>
                  <div className="mt-0.5 text-slate-700 leading-relaxed">{w.detail}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Visual Breakdown: Animated Donut Ring + Spending Rhythm Line Chart */}
      <section className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Donut Chart + Colorful Category Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.26, delay: 0.08 }}
          className="xl:col-span-6 bg-white border border-slate-200 rounded-2xl p-6 space-y-5 shadow-xs"
        >
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              Where Your Grocery Money Goes
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Hover any slice or click a category to see all items inside it
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="relative w-48 h-48 shrink-0">
              <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
                <circle
                  cx="100"
                  cy="100"
                  r={radius}
                  fill="none"
                  stroke="#f1f5f9"
                  strokeWidth="22"
                />
                {activeSpendCats.map((cat, idx) => {
                  const fraction =
                    summary.totalSpend > 0 ? cat.totalSpend / summary.totalSpend : 0;
                  const dashLength = Math.max(0, fraction * circumference - 2);
                  const dashOffset = -cumulativeFraction * circumference;
                  cumulativeFraction += fraction;
                  const isHovered = hoveredSlice?.category === cat.category;

                  return (
                    <motion.circle
                      key={cat.category}
                      cx="100"
                      cy="100"
                      r={radius}
                      fill="none"
                      stroke={cat.color}
                      strokeWidth={isHovered ? 27 : 22}
                      strokeDasharray={`${dashLength} ${circumference}`}
                      strokeDashoffset={dashOffset}
                      strokeLinecap="butt"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.35, delay: 0.04 * idx }}
                      onMouseEnter={() => setHoveredSlice(cat)}
                      onMouseLeave={() => setHoveredSlice(null)}
                      onClick={() => onOpenCategory(cat.category)}
                      className="cursor-pointer transition-all duration-150"
                    />
                  );
                })}
              </svg>

              <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-5 pointer-events-none">
                <span className="text-[11px] font-medium text-slate-500 truncate max-w-full">
                  {hoveredSlice ? hoveredSlice.category : 'Total Spent'}
                </span>
                <span className="font-mono text-lg font-bold text-slate-900 tabular-nums mt-0.5">
                  $
                  {hoveredSlice
                    ? hoveredSlice.totalSpend.toFixed(2)
                    : summary.totalSpend.toFixed(2)}
                </span>
                {hoveredSlice && (
                  <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                    {((hoveredSlice.totalSpend / summary.totalSpend) * 100).toFixed(0)}% of total
                  </span>
                )}
              </div>
            </div>

            <div className="flex-1 w-full space-y-2 max-h-56 overflow-y-auto pr-1">
              {activeSpendCats.map((cat) => {
                const pct =
                  summary.totalSpend > 0
                    ? (cat.totalSpend / summary.totalSpend) * 100
                    : 0;
                return (
                  <button
                    key={cat.category}
                    type="button"
                    onMouseEnter={() => setHoveredSlice(cat)}
                    onMouseLeave={() => setHoveredSlice(null)}
                    onClick={() => onOpenCategory(cat.category)}
                    className="w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left cursor-pointer"
                  >
                    <span className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-2.5 h-2.5 rounded-xs shrink-0"
                        style={{ backgroundColor: cat.color }}
                      />
                      <span className="text-xs font-medium text-slate-800 truncate">
                        {cat.category}
                      </span>
                    </span>
                    <span className="font-mono text-xs tabular-nums text-slate-700 shrink-0">
                      ${cat.totalSpend.toFixed(2)}{' '}
                      <span className="text-slate-400">({pct.toFixed(0)}%)</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </motion.div>

        {/* Spending Rhythm Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.26, delay: 0.14 }}
          className="xl:col-span-6 bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs"
        >
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              How Your Spending Grew This Month
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {hoveredDateIdx !== null && trendPoints[hoveredDateIdx]
                ? `${trendPoints[hoveredDateIdx].date}: +$${trendPoints[hoveredDateIdx].dailySpend.toFixed(2)} that day · $${trendPoints[hoveredDateIdx].cumulativeSpend.toFixed(2)} total so far`
                : 'Hover any dot to inspect that day’s grocery spending'}
            </p>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              viewBox="0 0 640 260"
              className="w-full h-56 min-w-[460px]"
              role="img"
              aria-label="Monthly grocery spending timeline"
            >
              <defs>
                <linearGradient id="consumerArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.28" />
                  <stop offset="65%" stopColor="#0ea5e9" stopOpacity="0.1" />
                  <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0.01" />
                </linearGradient>
                <linearGradient id="consumerLine" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="50%" stopColor="#0ea5e9" />
                  <stop offset="100%" stopColor="#6366f1" />
                </linearGradient>
              </defs>

              {[0, 0.25, 0.5, 0.75, 1].map((tick) => {
                const y = 212 - tick * 175;
                const val = Math.round(maxTrendVal * tick);
                return (
                  <g key={tick}>
                    <line
                      x1="50"
                      y1={y}
                      x2="616"
                      y2={y}
                      stroke="#e2e8f0"
                      strokeDasharray={tick === 0 ? undefined : '3 3'}
                    />
                    <text
                      x="44"
                      y={y + 4}
                      textAnchor="end"
                      className="fill-slate-400 text-[10px] font-mono"
                    >
                      ${val}
                    </text>
                  </g>
                );
              })}

              {(() => {
                const ceilingY = 212 - (summary.overallBudget / maxTrendVal) * 175;
                return (
                  <g>
                    <line
                      x1="50"
                      y1={ceilingY}
                      x2="616"
                      y2={ceilingY}
                      stroke="#f43f5e"
                      strokeWidth="1.5"
                      strokeDasharray="6 4"
                    />
                    <text
                      x="612"
                      y={ceilingY - 6}
                      textAnchor="end"
                      className="fill-rose-600 text-[10px] font-mono font-medium"
                    >
                      Monthly Limit ${summary.overallBudget.toFixed(0)}
                    </text>
                  </g>
                );
              })()}

              {areaPath && (
                <motion.path
                  d={areaPath}
                  fill="url(#consumerArea)"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.15 }}
                />
              )}

              {linePath && (
                <motion.path
                  d={linePath}
                  fill="none"
                  stroke="url(#consumerLine)"
                  strokeWidth="3"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                />
              )}

              {trendCoords.map(({ x, y, pt }, i) => {
                const over = pt.cumulativeSpend > summary.overallBudget;
                const showLabel =
                  i === 0 ||
                  i === trendCoords.length - 1 ||
                  i === Math.floor(trendCoords.length / 2);

                return (
                  <g
                    key={pt.date}
                    onMouseEnter={() => setHoveredDateIdx(i)}
                    onMouseLeave={() => setHoveredDateIdx(null)}
                    className="cursor-pointer"
                  >
                    <motion.circle
                      cx={x}
                      cy={y}
                      r={hoveredDateIdx === i ? 6 : 4}
                      fill={over ? '#f43f5e' : '#0ea5e9'}
                      stroke="#ffffff"
                      strokeWidth="2"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.2, delay: 0.03 * i }}
                    />
                    {showLabel && (
                      <text
                        x={x}
                        y="234"
                        textAnchor="middle"
                        className="fill-slate-500 text-[10px] font-mono"
                      >
                        {pt.date.slice(5)}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </motion.div>
      </section>

      {/* Popular Everyday Categories Grid (Quick Glance) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <h2 className="font-display text-base font-semibold text-slate-900">
            Categories at a Glance
          </h2>
          <span className="text-xs text-slate-500">
            Click any category to browse its groceries
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {summary.categories.map((cat, idx) => {
            const visual = getCategoryVisual(cat.category, config);
            const Icon = visual.icon;
            const fillPct = Math.min(100, cat.utilizationPct);

            return (
              <motion.button
                key={cat.category}
                type="button"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: Math.min(idx * 0.03, 0.28) }}
                whileHover={{ y: -3, scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={() => onOpenCategory(cat.category)}
                className="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-slate-300 shadow-xs transition-shadow hover:shadow-md cursor-pointer space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${visual.hex}18`, color: visual.hex }}
                  >
                    <Icon className="w-4 h-4" aria-hidden="true" />
                  </span>
                  <span className="font-mono text-xs text-slate-500 tabular-nums">
                    {cat.itemCount} {cat.itemCount === 1 ? 'item' : 'items'}
                  </span>
                </div>

                <div>
                  <div className="font-medium text-sm text-slate-900 truncate">
                    {cat.category}
                  </div>
                  <div className="mt-1 flex items-baseline justify-between gap-2 font-mono tabular-nums">
                    <span className="text-base font-semibold text-slate-900">
                      ${cat.totalSpend.toFixed(2)}
                    </span>
                    <span className="text-xs text-slate-500">
                      / ${cat.fixedBudget.toFixed(0)} limit
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${fillPct}%` }}
                      transition={{ duration: 0.5, delay: 0.04 * idx }}
                      className="h-full rounded-full"
                      style={{
                        backgroundColor:
                          cat.status === 'Over Budget' ? '#e11d48' : visual.hex,
                      }}
                    />
                  </div>
                  <StatusLabel status={cat.status} compact />
                </div>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Recent Purchases Feed */}
      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <h2 className="font-display text-base font-semibold text-slate-900">
            Recent Grocery Purchases
          </h2>
          <button
            type="button"
            onClick={onSeeAllGroceries}
            className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer"
          >
            <span>See all {summary.totalEntries} items</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {recentRecords.slice(0, 6).map((rec) => {
            const visual = getCategoryVisual(rec.category, config);
            const Icon = visual.icon;
            return (
              <div
                key={rec.id}
                className="px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50/75 transition-colors"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <span
                    className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${visual.hex}18`, color: visual.hex }}
                  >
                    <Icon className="w-4 h-4" aria-hidden="true" />
                  </span>
                  <div className="min-w-0">
                    <div className="font-medium text-sm text-slate-900 truncate">
                      {rec.itemName}
                    </div>
                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-1.5 mt-0.5">
                      <span>{rec.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{rec.store}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{rec.purchaseDate}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-5 ml-auto">
                  <div className="text-right font-mono tabular-nums">
                    <div className="text-sm font-semibold text-slate-900">
                      ${rec.totalCost.toFixed(2)}
                    </div>
                    <div
                      className={`text-xs ${
                        rec.variance < 0 ? 'text-rose-700' : 'text-emerald-700'
                      }`}
                    >
                      {rec.variance >= 0
                        ? `Saved $${rec.variance.toFixed(2)}`
                        : `Over $${Math.abs(rec.variance).toFixed(2)}`}
                    </div>
                  </div>
                  <StatusLabel status={rec.status} compact />
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
