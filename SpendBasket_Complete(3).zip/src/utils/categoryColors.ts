import {
  Apple,
  Beef,
  Coffee,
  Cookie,
  Croissant,
  Flame,
  Heart,
  Milk,
  ShoppingBag,
  Snowflake,
  Sparkles,
  Sun,
  Wheat,
  type LucideIcon,
} from 'lucide-react';
import type { BudgetConfig } from '../types/grocery.ts';

export interface CategoryVisual {
  hex: string;
  softBg: string;
  text: string;
  icon: LucideIcon;
}

export const BUILT_IN_CATEGORY_VISUALS: Record<string, CategoryVisual> = {
  'Fresh Fruits & Veggies': {
    hex: '#10b981',
    softBg: 'bg-emerald-50',
    text: 'text-emerald-700',
    icon: Apple,
  },
  'Milk, Cheese & Eggs': {
    hex: '#0ea5e9',
    softBg: 'bg-sky-50',
    text: 'text-sky-700',
    icon: Milk,
  },
  'Meat, Poultry & Fish': {
    hex: '#f43f5e',
    softBg: 'bg-rose-50',
    text: 'text-rose-700',
    icon: Beef,
  },
  'Bread & Bakery': {
    hex: '#f59e0b',
    softBg: 'bg-amber-50',
    text: 'text-amber-700',
    icon: Croissant,
  },
  'Snacks & Sweets': {
    hex: '#ec4899',
    softBg: 'bg-pink-50',
    text: 'text-pink-700',
    icon: Cookie,
  },
  'Drinks & Coffee': {
    hex: '#14b8a6',
    softBg: 'bg-teal-50',
    text: 'text-teal-700',
    icon: Coffee,
  },
  'Rice, Pasta & Grains': {
    hex: '#6366f1',
    softBg: 'bg-indigo-50',
    text: 'text-indigo-700',
    icon: Wheat,
  },
  'Spices, Sauces & Oils': {
    hex: '#f97316',
    softBg: 'bg-orange-50',
    text: 'text-orange-700',
    icon: Flame,
  },
  'Frozen Meals & Ice Cream': {
    hex: '#06b6d4',
    softBg: 'bg-cyan-50',
    text: 'text-cyan-700',
    icon: Snowflake,
  },
  'Breakfast & Cereal': {
    hex: '#eab308',
    softBg: 'bg-yellow-50',
    text: 'text-yellow-700',
    icon: Sun,
  },
  'Baby & Pet Care': {
    hex: '#84cc16',
    softBg: 'bg-lime-50',
    text: 'text-lime-700',
    icon: Heart,
  },
  'Cleaning & Home Supplies': {
    hex: '#8b5cf6',
    softBg: 'bg-violet-50',
    text: 'text-violet-700',
    icon: Sparkles,
  },
};

export const CUSTOM_COLOR_SWATCHES = [
  '#10b981',
  '#0ea5e9',
  '#f43f5e',
  '#f59e0b',
  '#ec4899',
  '#6366f1',
  '#14b8a6',
  '#f97316',
  '#8b5cf6',
  '#84cc16',
];

export function getCategoryVisual(
  category: string,
  config?: BudgetConfig
): CategoryVisual {
  const builtIn = BUILT_IN_CATEGORY_VISUALS[category];
  if (builtIn) return builtIn;

  const custom = config?.customCategories?.find(
    (c) => c.name.toLowerCase() === category.toLowerCase()
  );
  return {
    hex: custom?.color ?? '#64748b',
    softBg: 'bg-slate-100',
    text: 'text-slate-700',
    icon: ShoppingBag,
  };
}
